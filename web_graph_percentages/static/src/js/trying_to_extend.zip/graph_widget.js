/*-----------------------------------------------------------------------------
 * OpenERP web_graph_percentages
 *-----------------------------------------------------------------------------
 *
 * This namespace contains the Javascript code needed for module
 * "web_graph_percentages".
 */

openerp.web_graph_percentages = function(instance, local) {

    var QWeb = instance.web.qweb;
    var _t = instance.web._t;

    /**
     * -----------------------------------------------------------------
     * Graph Widget
     * -----------------------------------------------------------------
     *
     * Extends Graph Widget to add percentajes
     */

    instance.web_graph.Graph = instance.web_graph.Graph.extend({

        /**
         * post-rendering initialization code, at this point
         *
         * @return propagate asynchronous signal from parent class
         */
        start: function() {
            var self = this;

            var sup = this._super();

            console.log('start::result');
            console.log(sup)

            return $.when(sup)
        }

    });

}
