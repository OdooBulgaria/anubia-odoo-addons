/*-----------------------------------------------------------------------------
 * OpenERP web_graph_percentages
 *-----------------------------------------------------------------------------
 *
 * This namespace contains the Javascript code needed for module
 * "web_graph_percentages".
 */

openerp.web_graph_percentages = function(instance, local) {

    var QWeb = instance.web.qweb;
    var _t = instance.web._t;

    /**
     * -----------------------------------------------------------------
     * PivotTable (inherited)
     * -----------------------------------------------------------------
     *
     * Extends pivot table to add percentages option
     */

    instance.web_graph.PivotTable = instance.web_graph.PivotTable.extend({

        init: function (model, domain, fields, options) {
           result = this._super(model, domain, fields, options);

           // OK - this.fields.__percentage = {type: 'float', string:_t('Percentage')};
        },

        get_groups: function (groupbys, fields, domain) {

            var total = 0;

            this.model.query('id')
                .filter(domain)
                .context(this.context)
                .all()
                .then(function (items) {
                    total = items.length
                });

            // ?? console.log('get_groups::total');
            // ?? console.log(total);

            result = this._super(groupbys, fields, domain);

            // percentage_value = group.attributes.length / total * 100;
            // result.attrs.aggregates.__percentage = percentage_value;

            // ?? console.log('get_groups::result');
            // ?? console.log(result);

            return result;
        },

        make_cell: function (row, col, value, index, raw) {
            result = this._super(row, col, value, index, raw);

            console.log('make_cell');
            console.log(result);

            return result;
        }

    });

}
