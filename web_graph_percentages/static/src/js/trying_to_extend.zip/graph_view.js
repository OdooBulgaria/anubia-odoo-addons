/*-----------------------------------------------------------------------------
 * OpenERP web_graph_percentages
 *-----------------------------------------------------------------------------
 *
 * This namespace contains the Javascript code needed for module
 * "web_graph_percentages".
 */

openerp.web_graph_percentages = function(instance, local) {

    var QWeb = instance.web.qweb;
    var _t = instance.web._t;

    /**
     * -----------------------------------------------------------------
     * Web Graph View (inherited)
     * -----------------------------------------------------------------
     *
     * Extends graph view to add percentages option
     */

    instance.web_graph.GraphView = instance.web_graph.GraphView.extend({

        view_loading: function (fields_view_get) {
            this._super(fields_view_get);

            console.log(this.widget_config.measures);
            // if (this.widget_config.measures.length === 0) {
            //     this.widget_config.measures.push('__percentage');
            // }
        },

    });

}
